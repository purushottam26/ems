import React from 'react';
import { User } from '../../types';

interface TaskListNumbersProps {
  data?: User;
}

export function TaskListNumbers({ data }: TaskListNumbersProps) {
  const stats = [
    { label: 'Total Tasks', value: 18 },
    { label: 'Completed', value: 12 },
    { label: 'In Progress', value: 4 },
    { label: 'Pending', value: 2 },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
      {stats.map((stat, index) => (
        <div key={index} className="bg-white rounded-lg shadow p-4">
          <p className="text-sm font-medium text-gray-500">{stat.label}</p>
          <p className="text-2xl font-semibold text-gray-900">{stat.value}</p>
        </div>
      ))}
    </div>
  );
}