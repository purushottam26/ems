import React from 'react';
import { User } from '../types';
import { Building2, Users, Calendar, ClipboardList, Settings, LogOut } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  user: User;
  onLogout: () => void;
}

export function Layout({ children, user, onLogout }: LayoutProps) {
  return (
    <div className="flex h-screen">
      {/* Sidebar */}
      <div className="w-64 bg-indigo-700 text-white">
        <div className="p-4">
          <div className="flex items-center space-x-2">
            <Building2 className="h-8 w-8" />
            <span className="text-xl font-bold">EMS Portal</span>
          </div>
        </div>
        
        <nav className="mt-8">
          <div className="px-4 mb-4">
            <div className="flex items-center space-x-2 px-4 py-2 bg-indigo-800 rounded-lg">
              <Users className="h-5 w-5" />
              <span>Dashboard</span>
            </div>
            <div className="flex items-center space-x-2 px-4 py-2 mt-2 hover:bg-indigo-600 rounded-lg cursor-pointer">
              <Calendar className="h-5 w-5" />
              <span>Schedule</span>
            </div>
            <div className="flex items-center space-x-2 px-4 py-2 mt-2 hover:bg-indigo-600 rounded-lg cursor-pointer">
              <ClipboardList className="h-5 w-5" />
              <span>Tasks</span>
            </div>
            <div className="flex items-center space-x-2 px-4 py-2 mt-2 hover:bg-indigo-600 rounded-lg cursor-pointer">
              <Settings className="h-5 w-5" />
              <span>Settings</span>
            </div>
          </div>
        </nav>
      </div>

      {/* Main content */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <header className="bg-white shadow">
          <div className="flex justify-between items-center px-8 py-4">
            <h1 className="text-2xl font-semibold text-gray-800">Dashboard</h1>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm font-medium text-gray-900">{user.name}</p>
                <p className="text-xs text-gray-500">{user.role}</p>
              </div>
              <button
                onClick={onLogout}
                className="flex items-center space-x-1 text-gray-600 hover:text-gray-900"
              >
                <LogOut className="h-5 w-5" />
                <span>Logout</span>
              </button>
            </div>
          </div>
        </header>

        {/* Main content area */}
        <main className="flex-1 overflow-y-auto bg-gray-50 p-8">
          {children}
        </main>
      </div>
    </div>
  );
}