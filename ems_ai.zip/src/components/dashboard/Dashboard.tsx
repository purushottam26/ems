import React from 'react';
import { User, UserRole } from '../../types';
import { AdminDashboard } from './AdminDashboard';
import { EmployeeDashboard } from './EmployeeDashboard';

interface DashboardProps {
  user: User;
}

export function Dashboard({ user }: DashboardProps) {
  return user.role === UserRole.ADMIN ? (
    <AdminDashboard />
  ) : (
    <EmployeeDashboard />
  );
}