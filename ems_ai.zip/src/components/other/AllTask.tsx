import React from 'react';
import { Clock, CheckCircle, AlertTriangle } from 'lucide-react';

export function AllTask() {
  const tasks = [
    {
      id: 1,
      title: 'Review Q1 Reports',
      assignee: 'John Smith',
      dueDate: '2024-03-25',
      priority: 'high',
      status: 'in-progress',
    },
    {
      id: 2,
      title: 'Update Employee Handbook',
      assignee: 'Sarah Wilson',
      dueDate: '2024-03-28',
      priority: 'medium',
      status: 'pending',
    },
    {
      id: 3,
      title: 'Conduct Performance Reviews',
      assignee: 'Michael Brown',
      dueDate: '2024-03-30',
      priority: 'high',
      status: 'in-progress',
    },
  ];

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'high':
        return <AlertTriangle className="h-5 w-5 text-red-500" />;
      case 'medium':
        return <Clock className="h-5 w-5 text-yellow-500" />;
      case 'low':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      default:
        return null;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow">
      <div className="px-6 py-4 border-b border-gray-200">
        <h2 className="text-lg font-medium text-gray-900">All Tasks</h2>
      </div>
      <div className="divide-y divide-gray-200">
        {tasks.map((task) => (
          <div key={task.id} className="px-6 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                {getPriorityIcon(task.priority)}
                <div>
                  <p className="text-sm font-medium text-gray-900">{task.title}</p>
                  <p className="text-sm text-gray-500">Assigned to: {task.assignee}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-900">Due: {task.dueDate}</p>
                <span
                  className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    task.status === 'completed'
                      ? 'bg-green-100 text-green-800'
                      : task.status === 'in-progress'
                      ? 'bg-yellow-100 text-yellow-800'
                      : 'bg-gray-100 text-gray-800'
                  }`}
                >
                  {task.status}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}