import React, { useState, useEffect } from 'react';
import { Layout } from './components/Layout';
import { Login } from './components/auth/Login';
import { Dashboard } from './components/dashboard/Dashboard';
import { UserRole, User } from './types';

function App() {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const savedUser = localStorage.getItem('user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  }, []);

  const handleLogin = (email: string, password: string) => {
    // Demo login logic - replace with real authentication
    if (email === 'admin@company.com' && password === 'admin') {
      const adminUser = {
        id: '1',
        name: 'Admin User',
        email,
        role: UserRole.ADMIN,
      };
      setUser(adminUser);
      localStorage.setItem('user', JSON.stringify(adminUser));
    } else if (email === 'employee@company.com' && password === 'employee') {
      const employeeUser = {
        id: '2',
        name: 'John Employee',
        email,
        role: UserRole.EMPLOYEE,
      };
      setUser(employeeUser);
      localStorage.setItem('user', JSON.stringify(employeeUser));
    } else {
      alert('Invalid credentials');
    }
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {!user ? (
        <Login onLogin={handleLogin} />
      ) : (
        <Layout user={user} onLogout={handleLogout}>
          <Dashboard user={user} />
        </Layout>
      )}
    </div>
  );
}

export default App;